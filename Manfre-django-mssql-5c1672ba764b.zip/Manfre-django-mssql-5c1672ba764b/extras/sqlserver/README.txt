These folders contain add-ins for your SQL Server database to support 
additional Django features.

== Regular Expression Support ==

There are two options for using regular expressions in SQL Server 2005:

* regex_clr contains a .NET (2.0) assembly that adds regex user functions
* regex_vbscript contains regex user functions implemented in VBScript
